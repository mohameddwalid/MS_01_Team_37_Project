#include <stdio.h>
#include "pico/stdlib.h"

int main() {

    // Define LED pins
    const uint redLedPin = 19;    
    const uint greenLedPin = 20;  
    const uint blueLedPin = 21;   

    // Initialize LED pins
    gpio_init(redLedPin);
    gpio_init(greenLedPin);
    gpio_init(blueLedPin);

    // Set LED pins as output
    gpio_set_dir(redLedPin, GPIO_OUT);
    gpio_set_dir(greenLedPin, GPIO_OUT);
    gpio_set_dir(blueLedPin, GPIO_OUT);

    // Initially turn off all LEDs
    gpio_put(redLedPin, false);   
    gpio_put(greenLedPin, false); 
    gpio_put(blueLedPin, true);   

    // Initialize chosen serial port
    stdio_init_all();

   
    while (true) {
        
        sleep_ms(5000);

        // First sequence: Turn on each LED for 1 second, then off
        gpio_put(redLedPin, true);    
        sleep_ms(1000);
        gpio_put(redLedPin, false);   

        gpio_put(greenLedPin, true);  
        sleep_ms(1000);
        gpio_put(greenLedPin, false); 

        gpio_put(blueLedPin, false);  // Turn on Blue LED (active-low)
        sleep_ms(1000);
        gpio_put(blueLedPin, true);   // Turn off Blue LED
        sleep_ms(1000);

        // Turn on all LEDs together for 2 seconds
        gpio_put(redLedPin, true);    
        gpio_put(greenLedPin, true);  
        gpio_put(blueLedPin, false);  
        sleep_ms(2000);

        // Turn off all LEDs
        gpio_put(redLedPin, false);   
        gpio_put(greenLedPin, false); 
        gpio_put(blueLedPin, true);   
    }
}
